<?php
// htdocs/FINAL WEB/api/api_plot.php
require __DIR__ . '/api_bootstrap.php';
require __DIR__ . '/api_db.php';

$id = $_GET['id'] ?? '';
if ($id === '') { json_err('Missing id', 400); exit; }

try {
  $stmt = $pdo->prepare("
    SELECT 
      p.plot_code, p.section, p.lot, p.grave, p.status,
      o.name AS owner_name, o.contact AS owner_contact, o.email AS owner_email, 
      o.address AS owner_address, o.purchase_date,
      b.deceased_name, b.birth_date, b.death_date, b.burial_date, b.unique_code AS burial_id,
      pay.status AS payment_status, pay.amount_paid, pay.next_payment_due, pay.plan AS payment_plan,
      p.notes
    FROM plots p
    LEFT JOIN owners o   ON o.id = p.owner_id
    LEFT JOIN burials b  ON b.plot_code = p.plot_code
    LEFT JOIN payments pay ON pay.plot_code = p.plot_code
    WHERE p.plot_code = ?
    LIMIT 1
  ");
  $stmt->execute([$id]);
  $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
  json_ok($row);
} catch (Throwable $e) {
  json_err('API error: '.$e->getMessage(), 500);
}
