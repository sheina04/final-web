<?php
// /api/api_transaction.php
require __DIR__.'/api_db.php';

$q = isset($_GET['q']) ? trim($_GET['q']) : '';

$sql = "
  SELECT t.id, t.txn_id, t.customer_id, c.name AS customer_name,
         t.deceased_name, t.plot_code, t.service_type, t.amount,
         t.method, t.method_type, t.payment_date, t.status, t.created_at
  FROM transactions t
  JOIN customers c ON c.id = t.customer_id
";
$params = [];
if ($q !== '') {
  $sql .= " WHERE (t.txn_id LIKE :kw OR c.name LIKE :kw OR t.deceased_name LIKE :kw OR t.plot_code LIKE :kw)";
  $params[':kw'] = "%$q%";
}
$sql .= " ORDER BY t.created_at DESC LIMIT 300";

$stmt = pdo()->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

json_out($rows);
