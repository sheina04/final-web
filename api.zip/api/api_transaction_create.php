<?php
// Accepts multipart/form-data from the transaction form
require __DIR__ . '/api_config.php';
if ($_SERVER['REQUEST_METHOD']!=='POST') json_err(405,'Use POST');

// helpers
function uuidv4(){
  $data = random_bytes(16);
  $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
  $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);
  return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

$service = $_POST['service_type'] ?? '';
$deceased = trim($_POST['deceased_name'] ?? '');
$plot = trim($_POST['plot_code'] ?? '');
$amount = (float)($_POST['amount'] ?? 0);
$paydate = $_POST['payment_date'] ?? date('Y-m-d');
$method = $_POST['method'] ?? '';
$method_type = $_POST['method_type'] ?? '';
$status = 'paid'; // default after create

if(!$service || !$deceased || !$plot || !$amount || !$paydate || !$method || !$method_type){
  json_err(400,'Missing required fields');
}

$owner_id = null;
$customer_name = null;

try{
  $pdo->beginTransaction();

  if($service==='burial'){
    // New owner
    $name = trim($_POST['new_customer_name'] ?? '');
    if($name==='') json_err(400,'Customer name required for burial');
    $email = trim($_POST['new_customer_email'] ?? '');
    $phone = trim($_POST['new_customer_phone'] ?? '');
    $addr  = trim($_POST['new_customer_address'] ?? '');

    // upsert owner
    $q = $pdo->prepare("SELECT id FROM owners WHERE name=? AND (email <=> ?) LIMIT 1");
    $q->execute([$name, $email ?: null]);
    $owner_id = $q->fetchColumn();
    if(!$owner_id){
      $ins = $pdo->prepare("INSERT INTO owners(name,email,contact,address) VALUES(?,?,?,?)");
      $ins->execute([$name ?: null, $email ?: null, $phone ?: null, $addr ?: null]);
      $owner_id = (int)$pdo->lastInsertId();
    }
    $customer_name = $name;

    // ensure plot exists and link owner
    if(strpos($plot,'/')!==false){
      [$sec,$lt,$gr]=array_pad(explode('/',$plot),3,'');
    } else { $sec=$lt=$gr=''; }
    $pdo->prepare("
      INSERT INTO plots(plot_code,section,lot,grave,status,owner_id)
      VALUES(?,?,?,?,?,?)
      ON DUPLICATE KEY UPDATE owner_id=VALUES(owner_id), status=VALUES(status)
    ")->execute([$plot,$sec,$lt,$gr,'occupied',$owner_id]);

    // create burial row
    $uc = 'D'.date('Ymd_His');
    $pdo->prepare("INSERT INTO burials(plot_code,deceased_name,burial_date,unique_code) VALUES(?,?,?,?)")
        ->execute([$plot,$deceased,$paydate,$uc]);

  } else {
    // existing customer
    $owner_id = (int)($_POST['customer_id'] ?? 0);
    if(!$owner_id) json_err(400,'customer_id is required for existing services');
    $customer_name = $pdo->query("SELECT name FROM owners WHERE id=".$owner_id)->fetchColumn() ?: null;
  }

  // save receipt file
  $receipt_path = null;
  if(isset($_FILES['receipt']) && is_uploaded_file($_FILES['receipt']['tmp_name'])){
    $dir = __DIR__.'/uploads';
    if(!is_dir($dir)) @mkdir($dir,0777,true);
    $ext = pathinfo($_FILES['receipt']['name'], PATHINFO_EXTENSION);
    $fname = 'receipt_'.time().'_'.mt_rand(1000,9999).($ext?'.'.$ext:'');
    $dest = $dir.'/'.$fname;
    if(move_uploaded_file($_FILES['receipt']['tmp_name'],$dest)){
      $receipt_path = 'api/uploads/'.$fname; // public-ish path
    }
  }

  // create transaction
  $txn_id = uuidv4();
  $insT = $pdo->prepare("
    INSERT INTO transactions
      (txn_id, owner_id, customer_name, deceased_name, plot_code, service_type,
       amount, method, method_type, payment_date, status, receipt_path)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
  ");
  $insT->execute([$txn_id,$owner_id,$customer_name,$deceased,$plot,$service,$amount,$method,$method_type,$paydate,$status,$receipt_path]);

  $pdo->commit();
  json_ok(['ok'=>true,'id'=>$pdo->lastInsertId(),'txn_id'=>$txn_id]);
}catch(Throwable $e){
  if($pdo->inTransaction()) $pdo->rollBack();
  json_err(500,'Create failed: '.$e->getMessage());
}
