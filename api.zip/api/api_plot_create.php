<?php
// htdocs/FINAL WEB/api/api_plot_create.php
require __DIR__ . '/api_bootstrap.php';
require __DIR__ . '/api_db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { json_err('POST only', 405); exit; }

$input = json_decode(file_get_contents('php://input'), true) ?: [];

$plot_code  = trim($input['plot_code'] ?? '');
$status     = trim($input['status'] ?? 'available');
$section    = trim($input['section'] ?? '');
$lot        = trim($input['lot'] ?? '');
$grave      = trim($input['grave'] ?? '');
$res_for    = trim($input['reserved_for'] ?? '');
$expiry     = $input['expiry'] ?: null;

$owner_name    = trim($input['owner_name'] ?? '');
$owner_contact = trim($input['owner_contact'] ?? '');
$owner_email   = trim($input['owner_email'] ?? '');
$owner_address = trim($input['owner_address'] ?? '');
$purchase_date = $input['purchase_date'] ?: null;

$deceased_name = trim($input['deceased_name'] ?? '');

if ($plot_code === '') { json_err('plot_code required', 400); exit; }

try {
  $pdo->beginTransaction();

  // owner (optional)
  $owner_id = null;
  if ($owner_name !== '') {
    $stmt = $pdo->prepare("
      INSERT INTO owners(name,contact,email,address,purchase_date)
      VALUES (?,?,?,?,?)
    ");
    $stmt->execute([$owner_name,$owner_contact,$owner_email,$owner_address,$purchase_date]);
    $owner_id = (int)$pdo->lastInsertId();
  }

  // plot
  $stmt = $pdo->prepare("
    INSERT INTO plots(plot_code,section,lot,grave,status,reserved_for,reservation_expiry,owner_id)
    VALUES (?,?,?,?,?,?,?,?)
    ON DUPLICATE KEY UPDATE
      section=VALUES(section), lot=VALUES(lot), grave=VALUES(grave),
      status=VALUES(status), reserved_for=VALUES(reserved_for),
      reservation_expiry=VALUES(reservation_expiry),
      owner_id=VALUES(owner_id)
  ");
  $stmt->execute([$plot_code,$section,$lot,$grave,$status,$res_for,$expiry,$owner_id]);

  // burial (optional)
  if ($deceased_name !== '') {
    $stmt = $pdo->prepare("
      INSERT INTO burials(plot_code,deceased_name)
      VALUES(?,?)
      ON DUPLICATE KEY UPDATE deceased_name=VALUES(deceased_name)
    ");
    $stmt->execute([$plot_code,$deceased_name]);
  }

  $pdo->commit();
  json_ok(['ok'=>true]);
} catch (Throwable $e) {
  $pdo->rollBack();
  json_err('Save failed: '.$e->getMessage(), 500);
}
