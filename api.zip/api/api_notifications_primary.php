<?php
// final web/api/api_notifications_primary.php
require_once __DIR__.'/api_bootstrap.php';
require_once __DIR__.'/api_db.php';

try {
  // list latest 200 queued/sent notifications
  $stmt = $pdo->query("
    SELECT id, rule_type AS type, recipient_name AS recipient,
           recipient_email AS contact, status,
           DATE_FORMAT(sent_at, '%Y-%m-%d') AS sent_at
    FROM notification_queue
    ORDER BY COALESCE(sent_at, send_on) DESC
    LIMIT 200
  ");
  $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
  json_ok($rows);
} catch (Throwable $e) {
  json_err('DB error: '.$e->getMessage(), 500);
}
