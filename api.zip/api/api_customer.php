<?php
/* /api/api_customer.php?id=123 */
declare(strict_types=1);
require __DIR__.'/_bootstrap.php';
require __DIR__.'/api_db.php';

$pdo = pdo_conn();
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) fail('Invalid id', 422);

$st = $pdo->prepare("SELECT id, name, email, phone, address FROM customers WHERE id = :id LIMIT 1");
$st->execute([':id'=>$id]);
$row = $st->fetch();
if (!$row) fail('Not found', 404);
json_out($row);
