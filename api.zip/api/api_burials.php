<?php
require __DIR__.'/_bootstrap.php';
require __DIR__.'/api_db.php';
$q = "SELECT id, plot_code, deceased_name, burial_date, unique_code FROM burials ORDER BY id DESC LIMIT 20";
json_ok($pdo->query($q)->fetchAll());
