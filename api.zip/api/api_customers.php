<?php
/* /api/api_customers.php */
declare(strict_types=1);
require __DIR__.'/_bootstrap.php';
require __DIR__.'/api_db.php';

$pdo = pdo_conn();

/* we show customers, plus try to display their latest deceased/plot if any via owners/plots/burials */
$sql = "
  SELECT
    c.id,
    c.name,
    c.email,
    c.phone,
    c.address,
    /* best-effort: find any plot owned by someone with same name (optional) */
    (
      SELECT b.deceased_name
      FROM owners o
      JOIN plots p ON p.owner_id = o.id
      JOIN burials b ON b.plot_code = p.plot_code
      WHERE o.name = c.name
      ORDER BY b.id DESC LIMIT 1
    ) AS deceased_name,
    (
      SELECT p2.plot_code
      FROM owners o2
      JOIN plots p2 ON p2.owner_id = o2.id
      WHERE o2.name = c.name
      ORDER BY p2.plot_code ASC LIMIT 1
    ) AS plot_code
  FROM customers c
  ORDER BY c.name ASC
  LIMIT 1000
";
$rows = $pdo->query($sql)->fetchAll();
json_out($rows);
