<?php
// final web/api/notify_seed_queue.php
require_once __DIR__.'/api_bootstrap.php';
require_once __DIR__.'/api_db.php';

function put($pdo,$rule,$tpl,$rname,$remail,$plot,$dec,$eventDate,$sendOn,$payload=[]) {
  // generated column sent_on_date helps with UNIQUE constraint
  $sql = "INSERT IGNORE INTO notification_queue
          (rule_type, template_code, recipient_name, recipient_email, plot_code, deceased_name, event_date, send_on, status, payload_json)
          VALUES (:rule,:tpl,:rname,:remail,:plot,:dec,:ed,:sendon,'queued',:payload)";
  $stmt = $pdo->prepare($sql);
  $stmt->execute([
    ':rule'=>$rule, ':tpl'=>$tpl, ':rname'=>$rname, ':remail'=>$remail,
    ':plot'=>$plot, ':dec'=>$dec, ':ed'=>$eventDate, ':sendon'=>$sendOn,
    ':payload'=>json_encode($payload)
  ]);
  return $stmt->rowCount();
}

try {
  $pdo->beginTransaction();

  // 1) RENEWALS due within 60 days
  $renew = $pdo->query("
    SELECT r.days_before, t.code AS tpl,
           o.name owner_name, o.email owner_email,
           p.plot_code, pay.next_payment_due AS due
    FROM notification_rules r
    JOIN email_templates t ON t.code = r.template_code AND r.rule_type='RENEWAL' AND r.is_active=1 AND t.is_active=1
    JOIN payments pay ON pay.next_payment_due IS NOT NULL
    JOIN plots p ON p.plot_code = pay.plot_code
    LEFT JOIN owners o ON o.id = p.owner_id
    WHERE DATEDIFF(pay.next_payment_due, CURDATE()) BETWEEN 0 AND 60
  ")->fetchAll(PDO::FETCH_ASSOC);

  $insRenew=0;
  foreach ($renew as $row) {
    $sendOn = date('Y-m-d 09:00:00', strtotime($row['due'].' -'.$row['days_before'].' days'));
    $insRenew += put(
      $pdo,'RENEWAL',$row['tpl'],$row['owner_name'],$row['owner_email'],$row['plot_code'],null,
      $row['due'],$sendOn, ['plot_code'=>$row['plot_code']]
    );
  }

  // 2) EVENTS (birthday/death/burial anniv) within 60 days
  $rules = $pdo->query("
    SELECT rule_type, days_before, template_code
    FROM notification_rules r
    JOIN email_templates t ON t.code=r.template_code AND r.is_active=1 AND t.is_active=1
    WHERE r.rule_type IN ('BIRTHDAY','DEATH_ANNIV','BURIAL_ANNIV')
  ")->fetchAll(PDO::FETCH_KEY_PAIR|PDO::FETCH_GROUP);
  // build a single rowset and compute nearest upcoming date in PHP
  $events = $pdo->query("
    SELECT b.deceased_name, b.birth_date, b.death_date, b.burial_date,
           p.plot_code, o.name owner_name, o.email owner_email
    FROM burials b
    JOIN plots p ON p.plot_code=b.plot_code
    LEFT JOIN owners o ON o.id=p.owner_id
  ")->fetchAll(PDO::FETCH_ASSOC);

  $insEvents=0;
  foreach ($events as $row) {
    // BIRTHDAY
    if ($row['birth_date']) {
      $ed = date('Y').substr($row['birth_date'],4); // this year's birthday
      if ($ed >= date('Y-m-d') && $ed <= date('Y-m-d', strtotime('+60 days'))) {
        $daysBefore = (int)$pdo->query("SELECT days_before FROM notification_rules WHERE rule_type='BIRTHDAY' AND is_active=1 LIMIT 1")->fetchColumn();
        $tpl = (string)$pdo->query("SELECT template_code FROM notification_rules WHERE rule_type='BIRTHDAY' AND is_active=1 LIMIT 1")->fetchColumn();
        $sendOn = date('Y-m-d 09:00:00', strtotime($ed.' -'.$daysBefore.' days'));
        $insEvents += put($pdo,'BIRTHDAY',$tpl,$row['owner_name'],$row['owner_email'],$row['plot_code'],$row['deceased_name'],$ed,$sendOn);
      }
    }
    // DEATH_ANNIV
    if ($row['death_date']) {
      $ed = date('Y').substr($row['death_date'],4);
      if ($ed >= date('Y-m-d') && $ed <= date('Y-m-d', strtotime('+60 days'))) {
        $daysBefore = (int)$pdo->query("SELECT days_before FROM notification_rules WHERE rule_type='DEATH_ANNIV' AND is_active=1 LIMIT 1")->fetchColumn();
        $tpl = (string)$pdo->query("SELECT template_code FROM notification_rules WHERE rule_type='DEATH_ANNIV' AND is_active=1 LIMIT 1")->fetchColumn();
        $sendOn = date('Y-m-d 09:00:00', strtotime($ed.' -'.$daysBefore.' days'));
        $insEvents += put($pdo,'DEATH_ANNIV',$tpl,$row['owner_name'],$row['owner_email'],$row['plot_code'],$row['deceased_name'],$ed,$sendOn);
      }
    }
    // BURIAL_ANNIV
    if ($row['burial_date']) {
      $ed = date('Y').substr($row['burial_date'],4);
      if ($ed >= date('Y-m-d') && $ed <= date('Y-m-d', strtotime('+60 days'))) {
        $daysBefore = (int)$pdo->query("SELECT days_before FROM notification_rules WHERE rule_type='BURIAL_ANNIV' AND is_active=1 LIMIT 1")->fetchColumn();
        $tpl = (string)$pdo->query("SELECT template_code FROM notification_rules WHERE rule_type='BURIAL_ANNIV' AND is_active=1 LIMIT 1")->fetchColumn();
        $sendOn = date('Y-m-d 09:00:00', strtotime($ed.' -'.$daysBefore.' days'));
        $insEvents += put($pdo,'BURIAL_ANNIV',$tpl,$row['owner_name'],$row['owner_email'],$row['plot_code'],$row['deceased_name'],$ed,$sendOn);
      }
    }
  }

  // 3) ALL SOULS if within 60 days
  $nov2 = date('Y').'-11-02';
  if ($nov2 >= date('Y-m-d') && $nov2 <= date('Y-m-d', strtotime('+60 days'))) {
    $daysBefore = (int)$pdo->query("SELECT days_before FROM notification_rules WHERE rule_type='ALL_SOULS' AND is_active=1 LIMIT 1")->fetchColumn();
    $tpl = (string)$pdo->query("SELECT template_code FROM notification_rules WHERE rule_type='ALL_SOULS' AND is_active=1 LIMIT 1")->fetchColumn();

    $rows = $pdo->query("
      SELECT DISTINCT o.name owner_name, o.email owner_email, b.deceased_name, p.plot_code
      FROM burials b
      JOIN plots p ON p.plot_code=b.plot_code
      LEFT JOIN owners o ON o.id=p.owner_id
      WHERE o.email IS NOT NULL AND o.email <> ''
    ")->fetchAll(PDO::FETCH_ASSOC);

    foreach ($rows as $r) {
      $sendOn = date('Y-m-d 09:00:00', strtotime($nov2.' -'.$daysBefore.' days'));
      put($pdo,'ALL_SOULS',$tpl,$r['owner_name'],$r['owner_email'],$r['plot_code'],$r['deceased_name'],$nov2,$sendOn);
    }
  }

  $pdo->commit();
  json_ok(['ok'=>true, 'renewal_inserted'=>$insRenew, 'event_inserted'=>$insEvents]);
} catch (Throwable $e) {
  if ($pdo->inTransaction()) $pdo->rollBack();
  json_err('Seed error: '.$e->getMessage(), 500);
}
