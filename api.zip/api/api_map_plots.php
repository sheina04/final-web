<?php
// htdocs/FINAL WEB/api/api_map_plots.php
require __DIR__ . '/api_bootstrap.php';
require __DIR__ . '/api_db.php';

try {
  $rows = $pdo->query("
    SELECT plot_code, section, lot, grave, status
    FROM plots
    ORDER BY section, lot, grave
  ")->fetchAll(PDO::FETCH_ASSOC);
  json_ok($rows);
} catch (Throwable $e) { json_err($e->getMessage(), 500); }
