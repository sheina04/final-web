<?php
/* /api/api_transaction.php */
declare(strict_types=1);
require __DIR__.'/api_db.php';

$pdo = pdo_conn();

$q = isset($_GET['q']) ? trim((string)$_GET['q']) : '';
$params = [];
$where = '';
if ($q !== '') {
  $where = "WHERE (t.txn_id LIKE :kw OR t.customer_name LIKE :kw OR t.deceased_name LIKE :kw OR t.plot_code LIKE :kw)";
  $params[':kw'] = "%$q%";
}

$sql = "
  SELECT
    t.id, t.txn_id, t.customer_id, t.customer_name,
    t.deceased_name, t.plot_code, t.service_type,
    t.amount, t.method, t.method_type, t.payment_date, t.status
  FROM transactions t
  $where
  ORDER BY t.id DESC
  LIMIT 500
";
$st = $pdo->prepare($sql);
$st->execute($params);
$rows = $st->fetchAll();

foreach ($rows as &$r) {
  $r['method_display'] = ucfirst(str_replace('_',' ',$r['method'] ?? ''));
}
json_out($rows);
