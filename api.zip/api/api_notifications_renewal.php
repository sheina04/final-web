<?php
// final web/api/api_notifications_renewal.php
require_once __DIR__.'/api_bootstrap.php';
require_once __DIR__.'/api_db.php';

try {
  $sql = "
    SELECT 
      o.name AS customer,
      p.plot_code AS plot,
      pay.next_payment_due AS expiry,
      DATEDIFF(pay.next_payment_due, CURDATE()) AS days_left,
      CASE 
        WHEN pay.status='overdue' OR (pay.next_payment_due IS NOT NULL AND pay.next_payment_due < CURDATE()) THEN 'overdue'
        WHEN DATEDIFF(pay.next_payment_due, CURDATE()) <= 7 THEN 'urgent'
        ELSE 'pending'
      END AS status,
      NULL AS sent_at,
      pay.plot_code AS id
    FROM payments pay
    JOIN plots p ON p.plot_code = pay.plot_code
    LEFT JOIN owners o ON o.id = p.owner_id
    ORDER BY COALESCE(pay.next_payment_due, '9999-12-31')
    LIMIT 300
  ";
  $rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

  // format dates to YYYY-MM-DD for the UI
  foreach ($rows as &$r) {
    if ($r['expiry']) $r['expiry'] = substr($r['expiry'], 0, 10);
  }
  json_ok($rows);
} catch (Throwable $e) {
  json_err('DB error: '.$e->getMessage(), 500);
}
