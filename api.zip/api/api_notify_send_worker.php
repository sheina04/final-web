<?php
// final web/api/notify_send_worker.php
require_once __DIR__.'/api_bootstrap.php';
require_once __DIR__.'/api_db.php';

function render_tpl($subject,$body,$vars){
  foreach ($vars as $k=>$v){
    $subject = str_replace('{{'.$k.'}}', $v, $subject);
    $body    = str_replace('{{'.$k.'}}', $v, $body);
  }
  return [$subject,$body];
}

try {
  // pick up to 50 queued items whose send_on <= now
  $stmt = $pdo->prepare("
    SELECT q.*, t.subject, t.body
    FROM notification_queue q
    JOIN email_templates t ON t.code=q.template_code
    WHERE q.status='queued' AND q.send_on <= NOW()
    ORDER BY q.send_on
    LIMIT 50
  ");
  $stmt->execute();
  $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

  $sent = 0; $errs = 0;
  foreach ($rows as $r) {
    $vars = [
      'owner_name'   => $r['recipient_name'],
      'deceased_name'=> $r['deceased_name'] ?? '',
      'plot_code'    => $r['plot_code'] ?? '',
      'event_date'   => $r['event_date'] ?? '',
    ];
    [$subj,$body] = render_tpl($r['subject'],$r['body'],$vars);

    // TODO: integrate real mailer here. For now, consider it sent OK.
    $upd = $pdo->prepare("UPDATE notification_queue SET status='sent', sent_at=NOW(), error_msg=NULL WHERE id=?");
    $upd->execute([$r['id']]);
    $sent++;
  }

  json_ok(['processed'=>count($rows),'sent'=>$sent,'errors'=>$errs]);
} catch (Throwable $e) {
  json_err('Send worker error: '.$e->getMessage(), 500);
}
