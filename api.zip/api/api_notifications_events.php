<?php
// final web/api/api_notifications_events.php
require_once __DIR__.'/api_bootstrap.php';
require_once __DIR__.'/api_db.php';

try {
  // We return upcoming/nearby event rows. The UI doesn’t need every row.
  $sql = "
    SELECT 
      b.deceased_name AS deceased,
      p.plot_code AS plot,
      o.name AS contact_name,
      COALESCE(o.contact, o.email) AS contact_phone,
      -- show the next renewal due if exists
      pay.next_payment_due AS renewal_due,
      'pending' AS status,
      b.id AS id,
      -- pick an 'occasion' label depending on what's closest in the next 60 days
      CASE
        WHEN b.birth_date IS NOT NULL AND DATE_FORMAT(b.birth_date, CONCAT(YEAR(CURDATE()),'-%m-%d')) BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 60 DAY)
          THEN 'Birthday'
        WHEN b.death_date IS NOT NULL AND DATE_FORMAT(b.death_date, CONCAT(YEAR(CURDATE()),'-%m-%d')) BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 60 DAY)
          THEN 'Death Anniversary'
        WHEN b.burial_date IS NOT NULL AND DATE_FORMAT(b.burial_date, CONCAT(YEAR(CURDATE()),'-%m-%d')) BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 60 DAY)
          THEN 'Burial Anniversary'
        ELSE 'Remembrance'
      END AS occasion
    FROM burials b
    JOIN plots p ON p.plot_code = b.plot_code
    LEFT JOIN owners o ON o.id = p.owner_id
    LEFT JOIN payments pay ON pay.plot_code = p.plot_code
    ORDER BY b.deceased_name
    LIMIT 300
  ";
  $rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

  if (!$rows) $rows = [];
  // Format renewal_due
  foreach ($rows as &$r) {
    if ($r['renewal_due']) $r['renewal_due'] = substr($r['renewal_due'],0,10);
  }
  json_ok($rows);
} catch (Throwable $e) {
  json_err('DB error: '.$e->getMessage(), 500);
}
